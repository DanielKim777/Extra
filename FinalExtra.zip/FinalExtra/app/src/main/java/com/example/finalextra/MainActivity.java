package com.example.finalextra;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinner = findViewById(R.id.spinner);
        TextView welcomeTextView = findViewById(R.id.welcomeTextView);
        ImageView employeeImageView = findViewById(R.id.employeeImageView);


        ArrayList<String> list = new ArrayList<String>();

        RequestQueue queue = Volley.newRequestQueue(this);

        String url1 = "http://10.0.2.2:8080/extra/getIDs.jsp";
        StringRequest request1 = new StringRequest(Request.Method.GET, url1, new Response.Listener<String>() {
            @Override
            public void onResponse(String s) {
                String result = s.trim();
                String ids[] = result.split("#");

                for (int i = 0; i < ids.length; i++) {
                    list.add(ids[i]);
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, list);
                spinner.setAdapter(adapter);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Toast.makeText(MainActivity.this, "Error loading employee IDs", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(request1);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedId = parent.getSelectedItem().toString();

                String url2 = "http://10.0.2.2:8080/extra/getFirstLast.jsp?empid=" + selectedId;

                StringRequest request2 = new StringRequest(Request.Method.GET, url2, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String s) {
                        String result = s.trim();

                        if (!result.isEmpty()) {
                            String[] parts = result.split("#");
                            if (parts.length > 0) {
                                String[] employeeInfo = parts[0].split(",");
                                if (employeeInfo.length >= 2) {
                                    String firstName = employeeInfo[0];
                                    String lastName = employeeInfo[1];
                                    welcomeTextView.setText("Welcome! " + firstName + " " + lastName);
                                }
                            }
                        }
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        welcomeTextView.setText("Error loading employee information");
                    }
                });

                queue.add(request2);


                int empId = Integer.parseInt(selectedId);
                if (empId >= 100 && empId <= 104) {

                    int imageNumber = empId - 99;
                    String imageUrl = "http://10.0.2.2:8080/extra/images/" + imageNumber + ".jpg";

                    ImageRequest imageRequest = new ImageRequest(
                            imageUrl,
                            new Response.Listener<Bitmap>() {
                                @Override
                                public void onResponse(Bitmap bitmap) {
                                    employeeImageView.setImageBitmap(bitmap);
                                    employeeImageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                                    employeeImageView.setVisibility(View.VISIBLE);
                                }
                            },
                            0, 0,
                            Bitmap.Config.ARGB_8888,
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    Toast.makeText(MainActivity.this, "Error loading image", Toast.LENGTH_SHORT).show();
                                }
                            }
                    );
                    queue.add(imageRequest);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }
}